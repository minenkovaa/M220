var ptx_lunr_search_style = "textbook";
var ptx_lunr_docs = [
{
  "id": "syllabus",
  "level": "1",
  "url": "syllabus.html",
  "type": "Section",
  "number": "",
  "title": "Syllabus",
  "body": " Syllabus        Course Information   Office: Dana 237   Email:  minenkova@hartford.edu    Credits: 3   Class Meetings: Mon &Wed 11:20-12:35 in Dana 411    Catalog Description:  3 Credits  Linear equations and matrix algebra, determinants, vector spaces, linear independence and bases, linear transformations and their matrix representations, eigenvalues and eigenvectors, diagonalizable matrices. Selected topics from quadratic forms, linear programming, inner product spaces, or numerical linear algebra.  Prerequisite(s): M 144.    Course Overview and Objectives  This course is about techniques of matrix computations. By the end of the semester, you should be able to:   successfully complete computations by hand, including solving systems of equations in multiple methods, computing eigenvalues, and performing arithmetical operations on vectors and matrices.    demonstrate understanding of both algebraic and geometric perspectives of concepts such as vector spaces, linear independence, span, etc.    analyze mathematical statements and write logical arguments to justify the validity of these statements. For example, justifying a true\/false statement or describing the existence\/uniqueness of a solution.     Meta Objectives:     Recognize and challenge your own beliefs and feelings about mathematics.    Work well with other students.    Find work partners that have similar speed, curiosity and learning style.    Gain social competence in negotiating different ways of thinking.    Persevere when it gets difficult and frustrating.    Be ok making mistakes and learning from them.    Be more confident in doing mathematics.    Admit not knowing and ask questions to learn.    Be prepared and ready to try\/learn when coming to class.    Realize that mathematics is more about creating and deep thinking than memorizing procedures.    Be curious about mathematics.    Recognize how you learn best and put a plan into action.    Enjoy the challenge of reasoning.    Only accept mathematics that makes sense to you.    Communicate mathematical ideas in writing and orally.     You can find a more detailed list of skills under \"Learning Outcomes\".    Book  Linear Algebra: An Interactive Introduction. https:\/\/ximera.osu.edu\/oerlinalg\/LinearAlgebra     Important Dates (tentative)    Mastery Problems: In class every week.   Reflections: Fridays every week.   Midterm Exam 1: Thursday, September 24.   Midterm Exam 2: Thursday, November 19.   Final Exam: Final week.   Grading Policy      Grade  Requirements    For an A you need to do all of the following:  Write 10 reflections.     Complete 90% of the learning outcomes.     Pass 5 written assignments.    For a B you need to do all of the following:  Write 10 reflections.     Complete 80% of the learning outcomes.     Pass 4 written assignments.    For a C you need to do all of the following:  Write 10 reflections.     Complete 70% of the learning outcomes.     Pass 3 written assignments.    For a D you need to do all of the following:  Write 5 reflections.     Complete 60% of the learning outcomes.     Pass 1 written assignment.     If you do not pass all of the D-requirements, you will receive an F.   The plus\/minus grading system will be used. I reserve the right to adjust the grading scale.    Assignment Descriptions   Mastery Problems  Problem sets will be assigned for each topic. There is no deadline per se just a suggested date for finishing each assignment. Hence all the work could be submitted by December 8,2026 . A word of caution: try to finish your work as soon as possible, as it would become more stressful for you (and for me) if there are a lot of assignments accumulated at the end of the semester. In this regard, I will allow to present only 7 learning outcomes per week for the last two weeks (after the Thanksgiving break). You will need to present your solved problem sets to me in person during the class and answer the questions I might ask about how you solved the problems or about the related concepts.    Reflection Posts  Every week either I will post a prompt for you to react or you would need to reflect on what was happening in class that week: like the pace, difficulty of new topic, etc. You need to submit 10 posts (we have 15 weeks of class).    Midterms  The exam dates are already scheduled, so please mark your calendars now (midterms in our classroom at the usual meeting time). If you have special accommodations please talk to me as soon as you can.  There will be no scores assigned rather it will be marked which goals you achieved. If there is a problem that is checking the goal you have already achieved you do not have to solve it. The same works for the final.    Extra Credit Computational Project  The goals of a project are to familiarize students with MatLab (which, as a UHart student, you can get for free here: ) and to use the concepts from linear algebra to solve applied problems. All projects must be submitted through blackboard using the Assignment tool. Do NOT email the projects to me! I will not accept ANY late or incomplete projects. The grade will consist of 2 points: 1 ''for correctness'' and 1 ''for presentation''.     Class Preparation and Attendance  While attendance does not contribute to your overall grade, my expectation is that you attend class on a regular basis. If you choose to not to attend class, it is your responsibility to learn the material from the missed class period. Before I answer questions or review material from the date of absence I will require that you demonstrate to me that you have made significant progress in trying to learn the material on your own by, for example, going through the lecture notes or reading the textbook.   Collaboration  Working collaboratively with your classmates is highly encouraged. However, the work you present on individual assignments must be your own. Be proud of your work and show me your own thinking and understanding.    Tutoring Availability:  Whether it's to get regular extra help in a challenging class or just to schedule time for additional assistance on a particular course assignment, the Center for Student Success is here for you! Students can book appointments directly in Compass through their success networks. (No appointments needed for Drop-In services!) Students can also make one-on-one peer tutoring appointments by visiting, emailing, or calling the Center in GSU 230.  Tutoring Appointment Meeting Location: Harrison Libraries, Up main, center stairs \/ Outside L 305  Phone: 860-768-4999  Email: ctctutor@hartford.edu     Calculator Policy  No calculators are allowed during exams. .    Cell Phone Policy  Please be respectful and keep your cell on silent or vibrate and preferably put away in a bag during class. Phone usage is distracting to you and to others around you, and therefore is detrimental to learning. Even having a phone out on your desk can be distracting enough to miss out on important information or to pull your focus away from a problem. If you must answer a call or text (due to an emergency) please leave the room to do so.     Other Important Polices   Students with Disabilities:  If you have a documented disability for which you are requesting accommodations, you are encouraged to contact Access-Ability Services as soon as possible by calling (860) 768-4312, emailing tlopez@hartford.edu , or by stopping by the Access-Ability Services office in Auerbach Hall, Room 209. If your request for accommodations is approved, an Accommodation Letter will be emailed to your instructor(s) upon your request. Please discuss your accommodations with the instructor as soon as possible to make appropriate arrangements. Note that student requests for accommodations must be filed each semester. Visit the website and click on the ``Registering'' link for more info and a link to a video to walk you through the process.    Title IX and Sexual Assault  The University of Hartford and its faculty and staff are committed to assuring a safe and productive educational environment for all students. Title IX makes it clear that sexual misconduct and harassment based on sex and gender is a Civil Rights offense subject to the same kinds of accountability and support applied to offenses against protected categories such as race, national origin, etc. University faculty and staff members must report sexual misconduct or harassment to the University's Title IX Coordinator to provide the appropriate resources and support options.  Please report any incidents of sexual misconduct and harassment and bias-related incidents, by clicking HERE   What this means is that as your professor, I am required to report any incidents of sexual misconduct and harassment that are directly reported to me or of which I am somehow made aware.  See the University of Hartford Title IX Sexual Harassment\/Sexual Assault Policy HERE To learn more about Title IX on campus, go to:   Support and Reporting Options:   On Campus (confidential): Counseling &Psychological Services (CAPS) 768-4482; Live Safe App (anonymous)    On Campus (private, not confidential): Kenna Grant, AVP Equity &Opportunity: Office (860-768-4880) title9@hartford.edu or mckenna@hartford.edu ; Public Safety (768-7777)    Off Campus (confidential): Sexual Assault Crisis Service (24\/7 toll-free hotlines: 1-888-999-5545 for English, 1-888-568-8332 para Español); Interval House hotline: 860-.838-8467; CT Safe Connect 24\/7 hotline: 888-774-2900 St. Francis hospital (860-714-4000)   The Assistant Vice President for Equity&Opportunity serves as the University's Title IX Coordinator and is the de­signated agent of the University with responsibilities for coordinating Title IX compliance efforts. They oversee the implementation of grievance procedures, including the notification, investigation, and disposition of complaints, ensuring a fair and neutral process for all parties. They have been designated to handle inquiries regarding non-discrimination policies, including oversight of 504\/ADA and Title IX compliance, and questions regarding the policy.    University of Hartford Mental Health and Wellbeing Statement  Mental health is an important aspect of students' wellbeing and integral to positive academic experience and success. If during the semester you experience difficulties and would like support, consider contacting the University of Hartford's Counseling and Psychological Services (CAPS). CAPS offers a range of short-term, confidential counseling services available to all undergraduate and graduate students at no additional cost .  CAPS is located in the Gengras Student Union, room 313. To schedule an appointment, call 860.768.4482 or email CAPS at caps@hartford.edu . Office hours are Monday through Friday, 8:30 a.m. - 4:30 p.m.     Land Acknowledgement Policy  The University of Hartford resides on the historic homelands of the Sicaogs, Poquonocks, Wangunks and Tunxis; and that what is now called Connecticut encompasses the homelands of the Wappinger, Schaghticoke, Golden Hill Paugussett, Mohegan, Mashantucket Pequot, Eastern Pequot, Nipmuc, Quinnipiac, Niantic, and Lenape, as well as other Indigenous Peoples. We honor, respect, and appreciate the relationship that exists among these communities, nations, lands, and waterways, and aspire to uphold our responsibilities according to their example of stewardship.    Audio\/Visual Recording Policy  To encourage active engagement and academic inquiry in the classroom, as well as to safeguard the privacy of students and faculty, no form of audio or visual recording in the classroom is permitted without explicit permission from the professor\/instructor or without a letter from Disability Services, signed by the faculty member, authorizing the recording as an accommodation. Authorized recordings may only be used by a student who has obtained permission and may not be shared or distributed for any reason. Violation of this policy is an infraction of the University of Hartford Honor Code and academic regulations and will result in disciplinary action.   "
},
{
  "id": "syllabus-7-7",
  "level": "2",
  "url": "syllabus.html#syllabus-7-7",
  "type": "Table",
  "number": "1",
  "title": "Grading Policy",
  "body": " Grading Policy      Grade  Requirements    For an A you need to do all of the following:  Write 10 reflections.     Complete 90% of the learning outcomes.     Pass 5 written assignments.    For a B you need to do all of the following:  Write 10 reflections.     Complete 80% of the learning outcomes.     Pass 4 written assignments.    For a C you need to do all of the following:  Write 10 reflections.     Complete 70% of the learning outcomes.     Pass 3 written assignments.    For a D you need to do all of the following:  Write 5 reflections.     Complete 60% of the learning outcomes.     Pass 1 written assignment.    "
},
{
  "id": "outline",
  "level": "1",
  "url": "outline.html",
  "type": "Section",
  "number": "",
  "title": "Course Outline",
  "body": " Course Outline   This page provides the weekly outline for M246, including core topics, learning activities, deliverables, and recommended open educational resources (OER).    UHart Fall 2026 — M220: Linear Algebra Tentative Timeline   Semester begins: Monday, August 24, 2026.  Labor Day (No Classes): September 7, 2026.  Fall Break: October 8–11, 2026.  Classes Resume: October 12, 2026.  Homework is listed with the suggested due date. Exam times are tentative and will occur during the regularly scheduled class meeting for your class.   Tentative Weekly Schedule    Week  Dates  Topics \/ Outcomes  Deliverables    0  Aug 25 (Tue) \/ Aug 27 (Thu)  Introduction  HW-0 (Aug 28)    1  Sep 1 (Tue) \/ Sep 3 (Thu)  Vectors (V1–V6)  HW-V (Sep 4)    2  Sep 8 (Tue) \/ Sep 10 (Thu)  Systems of Equations (SE1–SE6)  HW-SE (Sep 11)    3  Sep 15 (Tue) \/ Sep 17 (Thu)  Matrices (M1–M6)  HW-M (Sep 18)    4  Sep 22 (Tue) \/ Sep 24 (Thu)  Span & Linear Independence (SLI1–SLI5) \/ Exam 1  Exam 1 (Sep 24)    5  Sep 29 (Tue) \/ Oct 1 (Thu)  Matrix Transformations (MT1–MT4)  HW-MT (Oct 2)    6  Oct 6 (Tue) \/ Oct 8 (Thu)  Invertibility & Determinants (ID1–ID5) \/ Fall Break  HW-ID (Oct 9)    7  Oct 13 (Tue) \/ Oct 15 (Thu)  Vector Spaces & Bases (VSB1–VSB5)  HW-VSB (Oct 16)    8  Oct 20 (Tue) \/ Oct 22 (Thu)  Eigentheory I (E1–E4)  HW-E1 (Oct 23)    9  Oct 27 (Tue) \/ Oct 29 (Thu)  Eigentheory II (E5–E7)  HW-E2 (Oct 30)    10  Nov 3 (Tue) \/ Nov 5 (Thu)  Eigentheory Practice and Applications  Review Set (Nov 6)    11  Nov 10 (Tue) \/ Nov 12 (Thu)  Exam 2 Review     12  Nov 17 (Tue) \/ Nov 19 (Thu)  Orthogonality I (O1–O3) \/ Exam 2  Exam 2 (Nov 19)    13  Nov 24 (Tue) \/ Nov 26 (Thu)  Orthogonality II (O4–O6)  HW-O (Nov 27)    14  Dec 1 (Tue) \/ Dec 3 (Thu)  Comprehensive Review  Portfolio Check    15  Dec 8 (Tue) \/ Dec 10 (Thu)  Final Review  Prepare for Final Exam      "
},
{
  "id": "outline-3-4",
  "level": "2",
  "url": "outline.html#outline-3-4",
  "type": "Table",
  "number": "2",
  "title": "Tentative Weekly Schedule",
  "body": " Tentative Weekly Schedule    Week  Dates  Topics \/ Outcomes  Deliverables    0  Aug 25 (Tue) \/ Aug 27 (Thu)  Introduction  HW-0 (Aug 28)    1  Sep 1 (Tue) \/ Sep 3 (Thu)  Vectors (V1–V6)  HW-V (Sep 4)    2  Sep 8 (Tue) \/ Sep 10 (Thu)  Systems of Equations (SE1–SE6)  HW-SE (Sep 11)    3  Sep 15 (Tue) \/ Sep 17 (Thu)  Matrices (M1–M6)  HW-M (Sep 18)    4  Sep 22 (Tue) \/ Sep 24 (Thu)  Span & Linear Independence (SLI1–SLI5) \/ Exam 1  Exam 1 (Sep 24)    5  Sep 29 (Tue) \/ Oct 1 (Thu)  Matrix Transformations (MT1–MT4)  HW-MT (Oct 2)    6  Oct 6 (Tue) \/ Oct 8 (Thu)  Invertibility & Determinants (ID1–ID5) \/ Fall Break  HW-ID (Oct 9)    7  Oct 13 (Tue) \/ Oct 15 (Thu)  Vector Spaces & Bases (VSB1–VSB5)  HW-VSB (Oct 16)    8  Oct 20 (Tue) \/ Oct 22 (Thu)  Eigentheory I (E1–E4)  HW-E1 (Oct 23)    9  Oct 27 (Tue) \/ Oct 29 (Thu)  Eigentheory II (E5–E7)  HW-E2 (Oct 30)    10  Nov 3 (Tue) \/ Nov 5 (Thu)  Eigentheory Practice and Applications  Review Set (Nov 6)    11  Nov 10 (Tue) \/ Nov 12 (Thu)  Exam 2 Review     12  Nov 17 (Tue) \/ Nov 19 (Thu)  Orthogonality I (O1–O3) \/ Exam 2  Exam 2 (Nov 19)    13  Nov 24 (Tue) \/ Nov 26 (Thu)  Orthogonality II (O4–O6)  HW-O (Nov 27)    14  Dec 1 (Tue) \/ Dec 3 (Thu)  Comprehensive Review  Portfolio Check    15  Dec 8 (Tue) \/ Dec 10 (Thu)  Final Review  Prepare for Final Exam    "
},
{
  "id": "Learning-Outcomes",
  "level": "1",
  "url": "Learning-Outcomes.html",
  "type": "Section",
  "number": "",
  "title": "Learning Outcomes",
  "body": " Learning Outcomes   By the end of this course, you should be able to:  Name: ____________________    #: ____________________    Vectors     Done  Code  Learning Outcome   V1 Add vectors.  V2 Scale vectors by a real number.  V3 Calculate the length of a vector.  V4 Compute the dot product between two vectors.  V5 Calculate the angle between two given vectors.  V6 Find the orthogonal projection of one vector onto another.      Systems of Equations     Done  Code  Learning Outcome   SE1 Identify whether a matrix is in Reduced Row Echelon Form.  SE2 Use Gaussian Elimination to put a matrix into Reduced Row Echelon Form.  SE3 Use the Reduced Row Echelon Form of an augmented matrix to describe the solution space of a system of linear equations.  SE4 Use pivot positions to determine whether a linear system is consistent.  SE5 Determine whether the solution to a consistent linear system is unique.  SE6 Determine the rank of a matrix from its Reduced Row Echelon Form.      Matrices     Done  Code  Learning Outcome   M1 Add matrices.  M2 Scale matrices by a real number.  M3 Perform matrix-vector multiplication.  M4 Perform matrix-matrix multiplication.  M5 Compute the transpose of a matrix.  M6 Translate a system of equations into a matrix equation and the vector equation form.      Span and Linear Independence     Done  Code  Learning Outcome   SLI1 Determine whether a vector can be expressed as a linear combination of given vectors.  SLI2 Determine whether a vector is in the span of a given set of vectors.  SLI3 Describe the span of a set of vectors using set notation.  SLI4 Use span to determine whether a linear system is consistent.  SLI5 Determine whether a given set of vectors is linearly independent.      Matrix Transformations     Done  Code  Learning Outcome   MT1 Determine if a transformation is linear.  MT2 Find the domain and range of a matrix transformation.  MT3 Compose matrix transformations.  MT4 Find the standard matrix of a matrix transformation.      Invertibility and Determinants     Done  Code  Learning Outcome   ID1 Use Gaussian Elimination to determine whether a matrix is invertible.  ID2 Find the inverse of an invertible matrix.  ID3 Compute the determinant of a matrix.  ID4 Use the determinant to determine whether a matrix is invertible.  ID5 Analyze determinants of products and inverses of matrices.      Vector Spaces and Bases     Done  Code  Learning Outcome   VSB1 Determine whether a set satisfies the definition of a vector space.  VSB2 Find a basis for an abstract vector space.  VSB3 Translate between coordinate systems for different bases.  VSB4 Find a basis for the null space of a matrix.  VSB5 Find a basis for the column space of a matrix.      Eigentheory     Done  Code  Learning Outcome   E1 Determine whether a vector is an eigenvector of a matrix.  E2 Find the eigenvalue associated with an eigenvector.  E3 Use the characteristic polynomial to find eigenvalues.  E4 Find the algebraic and geometric multiplicities of eigenvalues.  E5 Find a basis for an eigenspace.  E6 Determine whether a matrix is diagonalizable.  E7 Diagonalize a diagonalizable matrix.      Orthogonality     Done  Code  Learning Outcome   O1 Determine whether a given map is an inner product.  O2 Determine whether two vectors from an abstract vector space are orthogonal.  O3 Use the transpose to find a basis for the orthogonal complement of a vector space.  O4 Perform orthogonal decomposition.  O5 Use Gram-Schmidt orthogonalization to find an orthogonal basis.  O6 Find an orthonormal basis from an orthogonal basis.     "
},
{
  "id": "Learning-Outcomes-3-2",
  "level": "2",
  "url": "Learning-Outcomes.html#Learning-Outcomes-3-2",
  "type": "Table",
  "number": "3",
  "title": "",
  "body": "   Done  Code  Learning Outcome   V1 Add vectors.  V2 Scale vectors by a real number.  V3 Calculate the length of a vector.  V4 Compute the dot product between two vectors.  V5 Calculate the angle between two given vectors.  V6 Find the orthogonal projection of one vector onto another.   "
},
{
  "id": "Learning-Outcomes-4-2",
  "level": "2",
  "url": "Learning-Outcomes.html#Learning-Outcomes-4-2",
  "type": "Table",
  "number": "4",
  "title": "",
  "body": "   Done  Code  Learning Outcome   SE1 Identify whether a matrix is in Reduced Row Echelon Form.  SE2 Use Gaussian Elimination to put a matrix into Reduced Row Echelon Form.  SE3 Use the Reduced Row Echelon Form of an augmented matrix to describe the solution space of a system of linear equations.  SE4 Use pivot positions to determine whether a linear system is consistent.  SE5 Determine whether the solution to a consistent linear system is unique.  SE6 Determine the rank of a matrix from its Reduced Row Echelon Form.   "
},
{
  "id": "Learning-Outcomes-5-2",
  "level": "2",
  "url": "Learning-Outcomes.html#Learning-Outcomes-5-2",
  "type": "Table",
  "number": "5",
  "title": "",
  "body": "   Done  Code  Learning Outcome   M1 Add matrices.  M2 Scale matrices by a real number.  M3 Perform matrix-vector multiplication.  M4 Perform matrix-matrix multiplication.  M5 Compute the transpose of a matrix.  M6 Translate a system of equations into a matrix equation and the vector equation form.   "
},
{
  "id": "Learning-Outcomes-6-2",
  "level": "2",
  "url": "Learning-Outcomes.html#Learning-Outcomes-6-2",
  "type": "Table",
  "number": "6",
  "title": "",
  "body": "   Done  Code  Learning Outcome   SLI1 Determine whether a vector can be expressed as a linear combination of given vectors.  SLI2 Determine whether a vector is in the span of a given set of vectors.  SLI3 Describe the span of a set of vectors using set notation.  SLI4 Use span to determine whether a linear system is consistent.  SLI5 Determine whether a given set of vectors is linearly independent.   "
},
{
  "id": "Learning-Outcomes-7-2",
  "level": "2",
  "url": "Learning-Outcomes.html#Learning-Outcomes-7-2",
  "type": "Table",
  "number": "7",
  "title": "",
  "body": "   Done  Code  Learning Outcome   MT1 Determine if a transformation is linear.  MT2 Find the domain and range of a matrix transformation.  MT3 Compose matrix transformations.  MT4 Find the standard matrix of a matrix transformation.   "
},
{
  "id": "Learning-Outcomes-8-2",
  "level": "2",
  "url": "Learning-Outcomes.html#Learning-Outcomes-8-2",
  "type": "Table",
  "number": "8",
  "title": "",
  "body": "   Done  Code  Learning Outcome   ID1 Use Gaussian Elimination to determine whether a matrix is invertible.  ID2 Find the inverse of an invertible matrix.  ID3 Compute the determinant of a matrix.  ID4 Use the determinant to determine whether a matrix is invertible.  ID5 Analyze determinants of products and inverses of matrices.   "
},
{
  "id": "Learning-Outcomes-9-2",
  "level": "2",
  "url": "Learning-Outcomes.html#Learning-Outcomes-9-2",
  "type": "Table",
  "number": "9",
  "title": "",
  "body": "   Done  Code  Learning Outcome   VSB1 Determine whether a set satisfies the definition of a vector space.  VSB2 Find a basis for an abstract vector space.  VSB3 Translate between coordinate systems for different bases.  VSB4 Find a basis for the null space of a matrix.  VSB5 Find a basis for the column space of a matrix.   "
},
{
  "id": "Learning-Outcomes-10-2",
  "level": "2",
  "url": "Learning-Outcomes.html#Learning-Outcomes-10-2",
  "type": "Table",
  "number": "10",
  "title": "",
  "body": "   Done  Code  Learning Outcome   E1 Determine whether a vector is an eigenvector of a matrix.  E2 Find the eigenvalue associated with an eigenvector.  E3 Use the characteristic polynomial to find eigenvalues.  E4 Find the algebraic and geometric multiplicities of eigenvalues.  E5 Find a basis for an eigenspace.  E6 Determine whether a matrix is diagonalizable.  E7 Diagonalize a diagonalizable matrix.   "
},
{
  "id": "Learning-Outcomes-11-2",
  "level": "2",
  "url": "Learning-Outcomes.html#Learning-Outcomes-11-2",
  "type": "Table",
  "number": "11",
  "title": "",
  "body": "   Done  Code  Learning Outcome   O1 Determine whether a given map is an inner product.  O2 Determine whether two vectors from an abstract vector space are orthogonal.  O3 Use the transpose to find a basis for the orthogonal complement of a vector space.  O4 Perform orthogonal decomposition.  O5 Use Gram-Schmidt orthogonalization to find an orthogonal basis.  O6 Find an orthonormal basis from an orthogonal basis.   "
},
{
  "id": "notes-week-01",
  "level": "1",
  "url": "notes-week-01.html",
  "type": "Section",
  "number": "",
  "title": "Week 1. Matrix operations; properties",
  "body": " Week 1. Matrix operations; properties   Tuesday  Introduction to course.    Thursday  Matrix operations and their properties.   "
},
{
  "id": "notes-week-02",
  "level": "1",
  "url": "notes-week-02.html",
  "type": "Section",
  "number": "",
  "title": "Week 2: Determinants; inverses; rank",
  "body": " Week 2: Determinants; inverses; rank   Tuesday  Determinants and their properties.    Thursday  Inverses and rank.   "
},
{
  "id": "notes-week-03",
  "level": "1",
  "url": "notes-week-03.html",
  "type": "Section",
  "number": "",
  "title": "Week 3: Systems; eigenvalues\/eigenvectors",
  "body": " Week 3: Systems; eigenvalues\/eigenvectors   Tuesday  Systems of equations and their solution.    Thursday  Eigenvalues and eigenvectors.   "
},
{
  "id": "notes-week-04",
  "level": "1",
  "url": "notes-week-04.html",
  "type": "Section",
  "number": "",
  "title": "Week 4: Partial derivatives; higher-order derivatives",
  "body": " Week 4: Partial derivatives; higher-order derivatives   Tuesday  Partial derivatives and their properties.    Thursday  Higher-order derivatives and their properties.   "
},
{
  "id": "notes-week-05",
  "level": "1",
  "url": "notes-week-05.html",
  "type": "Section",
  "number": "",
  "title": "Week 5: Multiple integrals; vector calculus",
  "body": " Week 5: Multiple integrals; vector calculus   Tuesday  Multiple integrals and their properties.    Thursday  Vector calculus.   "
},
{
  "id": "notes-week-06",
  "level": "1",
  "url": "notes-week-06.html",
  "type": "Section",
  "number": "",
  "title": "Week 6: First-order ODEs (separable, linear, exact)",
  "body": " Week 6: First-order ODEs (separable, linear, exact)   Tuesday  First-order ODEs: separable and linear equations.    Thursday  First-order ODEs: exact equations.   "
},
{
  "id": "notes-week-07",
  "level": "1",
  "url": "notes-week-07.html",
  "type": "Section",
  "number": "",
  "title": "Week 7: Second-order linear ODEs",
  "body": " Week 7: Second-order linear ODEs   Tuesday  Second-order linear ODEs with constant coefficients.    Thursday  Second-order linear ODEs with variable coefficients.   "
},
{
  "id": "notes-week-08",
  "level": "1",
  "url": "notes-week-08.html",
  "type": "Section",
  "number": "",
  "title": "Week 8: Systems; Laplace transform; numerical intro",
  "body": " Week 8: Systems; Laplace transform; numerical intro   Tuesday  Systems of ODEs and their solution.    Thursday  Laplace transform and its application to solving ODEs; introduction to numerical methods for ODEs.   "
},
{
  "id": "notes-week-09",
  "level": "1",
  "url": "notes-week-09.html",
  "type": "Section",
  "number": "",
  "title": "Week 9: PDE, their Classification; physical interpretation",
  "body": " Week 9: PDE, their Classification; physical interpretation   Tuesday  Classification of PDEs.    Thursday  Physical interpretation of PDEs.   "
},
{
  "id": "notes-week-10",
  "level": "1",
  "url": "notes-week-10.html",
  "type": "Section",
  "number": "",
  "title": "Week 10: Heat and wave equations",
  "body": " Week 10: Heat and wave equations   Tuesday  Heat and wave equations and their solution.    Thursday  Physical interpretation of heat and wave equations.   "
},
{
  "id": "notes-week-11",
  "level": "1",
  "url": "notes-week-11.html",
  "type": "Section",
  "number": "",
  "title": "Week 11",
  "body": " Week 11   Tuesday      Thursday     "
},
{
  "id": "notes-week-12",
  "level": "1",
  "url": "notes-week-12.html",
  "type": "Section",
  "number": "",
  "title": "Week 12",
  "body": " Week 12   Tuesday      Thursday     "
},
{
  "id": "notes-week-13",
  "level": "1",
  "url": "notes-week-13.html",
  "type": "Section",
  "number": "",
  "title": "Week 13",
  "body": " Week 13   Tuesday      Thursday     "
},
{
  "id": "notes-week-14",
  "level": "1",
  "url": "notes-week-14.html",
  "type": "Section",
  "number": "",
  "title": "Week 14",
  "body": " Week 14   Tuesday      Thursday     "
},
{
  "id": "notes-week-15",
  "level": "1",
  "url": "notes-week-15.html",
  "type": "Section",
  "number": "",
  "title": "Week 15",
  "body": " Week 15   Tuesday      Thursday     "
},
{
  "id": "activity-01-intro-activity",
  "level": "1",
  "url": "activity-01-intro-activity.html",
  "type": "Worksheet",
  "number": "",
  "title": "Introduction Activity",
  "body": " Introduction Activity    This is the introduction to the activity.      This is the first exercise.    "
},
{
  "id": "activity-01-intro-activity-3",
  "level": "2",
  "url": "activity-01-intro-activity.html#activity-01-intro-activity-3",
  "type": "Worksheet Exercise",
  "number": "1",
  "title": "",
  "body": "  This is the first exercise.   "
},
{
  "id": "handouts",
  "level": "1",
  "url": "handouts.html",
  "type": "Chapter",
  "number": "",
  "title": "Handouts",
  "body": " Handouts    "
},
{
  "id": "homework",
  "level": "1",
  "url": "homework.html",
  "type": "Chapter",
  "number": "",
  "title": "Homework",
  "body": " Homework    "
},
{
  "id": "resources",
  "level": "1",
  "url": "resources.html",
  "type": "Section",
  "number": "",
  "title": "Resources used in compiling this course",
  "body": " Resources used in compiling this course        Course Information  This is the syllabus for M246 Applied Math for CE for Fall 2026. It is a 4 credit course.   Instructor  Dr. Anastasia Minenkova, Dana Hall 237, minenkova@hartford.edu .    Office Hours  TBD. Check Blackboard for the most up to date information on office hours.    Class meets  TTh 8:00-9:30 a.m. in Dana Hall 205    Course Description  Matrix algebra, systems of linear algebraic equations, eigenvalues and eigenvectors; first- and second-order linear differential equations and systems of linear differential equations; an introduction to partial differential equations; an introduction to differential and integral multivariable calculus (A student may not receive credit for both this course and M 242.)    Prerequisite  M145.      "
},
{
  "id": "new-2",
  "level": "2",
  "url": "resources.html#new-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "M246 Applied Math for CE "
}
]

var ptx_lunr_idx = lunr(function () {
  this.ref('id')
  this.field('title')
  this.field('body')
  this.metadataWhitelist = ['position']

  ptx_lunr_docs.forEach(function (doc) {
    this.add(doc)
  }, this)
})
